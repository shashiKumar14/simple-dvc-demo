
def test_case():
    a=1
    b=1
    assert a==b