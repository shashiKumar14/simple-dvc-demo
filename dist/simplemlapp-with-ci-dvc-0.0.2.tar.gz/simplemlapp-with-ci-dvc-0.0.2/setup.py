from setuptools import setup, find_packages

setup(
    name="simplemlapp-with-ci-dvc",
    version="0.0.2",
    description="its a wine Q package", 
    author="shashiKumar14", 
    packages=find_packages(),
    license="MIT"
)